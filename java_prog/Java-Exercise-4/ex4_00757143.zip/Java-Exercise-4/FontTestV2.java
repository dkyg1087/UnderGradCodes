package ntou.cs. java2020.ex4;

// Test program for font display.
import javax.swing.JFrame;

public class FontTestV2 {
	public static void main(String[] args) {
		FontFrameV2 myFontFrame = new FontFrameV2();
		myFontFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myFontFrame.setSize(400, 200); // set frame size
		myFontFrame.setVisible(true); // display frame
	}
} // end class FontTest
