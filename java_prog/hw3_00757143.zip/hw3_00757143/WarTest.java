package ntou.cs.java2020.hw3;//00757143 楊明哲

public class WarTest {//War主程式
	public static void main(String args[]) {
		War war = new War();
		war.battle();
	}
}
