package ntou.cs.java2020.hw3;//00757143 楊明哲

public interface Bonus {
	int getBonus(int salary);//老師提供
}
