package ntou.cs.java2020.hw3;//00757143 楊明哲

public interface ATK { //老師提供
	double attack();
	double defend();
}
