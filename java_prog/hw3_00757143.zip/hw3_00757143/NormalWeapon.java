package ntou.cs.java2020.hw3;//00757143 楊明哲

import java.util.Random;
public class NormalWeapon extends Weapon{
    NormalWeapon(double attack,double defense){
        super(attack,defense);
    }//產生正常武器
}